package command;

public record CommandContext(Command cmd) {
}
